./build/greeter_server -address 0.0.0.0:50051 -roots root.pem -cert chain.pem -keyFile leaf.keyid -verifyClient
