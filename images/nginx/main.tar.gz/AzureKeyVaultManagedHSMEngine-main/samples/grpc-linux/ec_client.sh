./build/greeter_client -address localhost:50051 -name localhost -roots contoso_ecc_cert.cer -cert contoso_ecc_cert.cer -keyFile ecleaf.keyid
