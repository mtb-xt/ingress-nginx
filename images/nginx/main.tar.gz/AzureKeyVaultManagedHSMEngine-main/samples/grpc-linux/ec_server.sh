./build/greeter_server -address 0.0.0.0:50051 -roots contoso_ecc_cert.cer -cert contoso_ecc_cert.cer -keyFile ecleaf.keyid -verifyClient
